﻿using Cars;

internal class Seat : ICar
{
}