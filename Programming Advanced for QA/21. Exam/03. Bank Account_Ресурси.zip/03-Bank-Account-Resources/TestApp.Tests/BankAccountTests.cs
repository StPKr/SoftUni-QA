using NUnit.Framework;

namespace TestApp.Tests;

[TestFixture]
public class BankAccountTests
{
    [Test]
    public void Test_Constructor_InitialBalanceIsSet()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_Deposit_PositiveAmount_IncreasesBalance()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_Deposit_NegativeAmount_ThrowsArgumentException()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_Withdraw_ValidAmount_DecreasesBalance()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_Withdraw_NegativeAmount_ThrowsArgumentException()
    {
        // TODO: finish the test
    }

    [Test]
    public void Test_Withdraw_AmountGreaterThanBalance_ThrowsArgumentException()
    {
        // TODO: finish the test
    }
}
